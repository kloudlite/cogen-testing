import os
import yaml
from .agent_runner import setupAgentApp
from fastapi import FastAPI
import importlib.util
import sys
from ..tool_runner import ToolRunner
import asyncio

httpApp = FastAPI()

# def run(agent_name: str):
agent_name = sys.argv[1]
am_folder_path = '.am'
if not os.path.exists(am_folder_path):
    raise FileNotFoundError(f"The folder '{am_folder_path}' does not exist.")

# Specify the path to your YAML files
agents_yaml_file_path = os.path.join(am_folder_path, 'agents.yaml')
if not os.path.exists(agents_yaml_file_path):
    agents_yaml_file_path = os.path.join(am_folder_path, 'agents.yml')

# Open the YAML files and load their content
with open(agents_yaml_file_path, 'r') as agents_file:
    agents_list = yaml.safe_load(agents_file)

# Transform lists into dictionaries with names as keys
agents = {item['name']: item for item in agents_list}

# def runAppWithTools(app): 
am_folder_path = '.am'
if not os.path.exists(am_folder_path):
  raise FileNotFoundError(f"The folder '{am_folder_path}' does not exist.")

# Specify the path to your YAML files
tools_yaml_file_path = os.path.join(am_folder_path, 'tools.yaml')
if not os.path.exists(tools_yaml_file_path):
  tools_yaml_file_path = os.path.join(am_folder_path, 'tools.yml')

# Open the YAML files and load their content
with open(tools_yaml_file_path, 'r') as tools_file:
  tools_list = yaml.safe_load(tools_file)

# Transform lists into dictionaries with names as keys
tools = {item['name']: item for item in tools_list}


localToolMetadata = {}
for tool_name in tools:
  tool_info = tools[tool_name]
  module_name, class_name = tool_info['tool'].rsplit('.', 1)
  spec = importlib.util.find_spec(module_name)
  if spec is None:
    raise ImportError(f"Module '{module_name}' not found.")
  module = importlib.util.module_from_spec(spec)
  spec.loader.exec_module(module)
  tool_class = getattr(module, class_name)

  toolRunner = ToolRunner(tool_class, tool_info, httpApp)
  httpApp.mount(f'/tools/{tool_name}', toolRunner.app)
  localToolMetadata[tool_name] = toolRunner.getToolMetadata()
asyncio.create_task(setupAgentApp(httpApp, agents[agent_name], localToolMetadata))
