import hashlib
import os
import json
import yaml
import base64
import httpx
import asyncio
from openai import OpenAI
from fastapi import HTTPException
from fastapi.responses import StreamingResponse

client = OpenAI()

tool_metadata = {}

async def http_get(url, headers={}):
    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=headers)
        return response 

async def http_post(url, headers={}, json={}):
    async with httpx.AsyncClient() as client:
        response = await client.post(url, headers=headers, json=json)
        return response
    

def split_repo_string(input_string):
    # Initialize default values
    repo_url = None
    branch_name = "master"
    tool_name = None

    parts = input_string.rsplit('.', 1)
    tool_name = parts[-1]

    if len(parts) == 1:
        return None, None, tool_name

    if len(parts) == 2:
        repo_url = parts[0]
        repoparts = repo_url.split('#')
        if len(repoparts) == 2:
            repo_url = repoparts[0]
            branch_name = repoparts[1]
        elif len(repoparts) == 1:
            repo_url = repoparts[0]
        else :
            raise ValueError("Invalid repo url")
        return repo_url, branch_name, tool_name
    
def hostedUrl(repo_url, branch_name, tool_name):
    if repo_url == None and branch_name == None:
        return f"tools/{tool_name}"
    hash_input = f"{repo_url}#{branch_name}.{tool_name}"
    hash_object = hashlib.md5(hash_input.encode())
    return hash_object.hexdigest()

def convert_tool_metadata_to_tools(tool_metadata):
    tools = []
    for tool_name, tool_data in tool_metadata.items():
        tool_type = tool_data.get('functions')  # Access the function details
        tool_entry = {
            "type": "function",
                "function": {
                    "name": "name_conversation",
                    "description": "A tool to generate a title for this conversation",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "title": {
                                "type": "string",
                                "description": "The title of the conversation",
                            },
                        },
                        "required": ["title"],
                        "additionalProperties": False
                    },
                "strict": True
            }
        }
        tools.append(tool_entry)
        for func in tool_type:  # Iterate over the functions
            tool_entry = {
                "type": "function",
                "function": {
                    "name": tool_name + "-" + func.get('name'),
                    "description": func.get('description'),
                    "parameters": {
                        "type": "object",
                        "properties": func.get('parameters', {}),
                        "required": [prop for prop in func.get('parameters', {})],
                        "additionalProperties": False
                    },
                    "strict": True
                }
            }
            tools.append(tool_entry)
    return tools

async def handleOpenAIRequest(model: str,payload: dict, tool_metadata: dict):
    messages = payload.get('messages', [])
    tools = convert_tool_metadata_to_tools(tool_metadata)
    completion = client.chat.completions.create(
        model=model,
        messages=messages,
        tools=tools,
        stream=False,
    )

    r = completion.choices[0]
    task = []
    if r.finish_reason == "length":
        raise Exception("Length limit exceeded")
    elif r.finish_reason == "stop":
        return completion
    elif r.finish_reason == "tool_calls":
        messages.append(r.message)
        for tool_call in r.message.tool_calls:
            if tool_call.function.name == "name_conversation":
                continue
            name = tool_call.function.name
            args = json.loads(tool_call.function.arguments)
            async def process(name, args, id):
                result = await call_function(name, args)
                messages.append({
                    "role": "tool",
                    "tool_call_id": id,
                    "content": result["result"]
                })
            task.append(process(name, args, tool_call.id))
        await asyncio.gather(*task)
        payload["messages"] = messages
        return await handleOpenAIRequest(model, payload, tool_metadata)
    else:
        raise Exception("Unknown finish reason")
    
async def handleOpenAIStreamRequest(model: str,payload: dict, tool_metadata: dict):
    messages = payload.get('messages', [])
    tools = convert_tool_metadata_to_tools(tool_metadata)
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            tools=tools,
            stream=True,
        )
        final_tool_calls = {}
        chunkCount = 0
        for chunk in response:
            r = chunk.choices[0]
            chunkCount += 1
            if r.finish_reason == "length":
                yield f"error: Length limit exceeded$\n\n"
                break
            elif r.finish_reason == "stop":
                break
            elif r.finish_reason == "tool_calls":
                #process calls
                tasks = []
                messages.append({
                    "role": "assistant",
                    "tool_calls":[tool_call for tool_call in final_tool_calls.values()]
                })
                for _, tool_call in final_tool_calls.items():
                    name = tool_call.function.name
                    if name == "name_conversation":
                        yield f"$function_call:$name_conversation {tool_call.function.arguments}$\n\n"
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call.id,
                            "content": "done"
                        })
                        continue
                    args = json.loads(tool_call.function.arguments)
                    async def process(name, args, id):
                        result = await call_function(name, args)
                        messages.append({
                            "role": "tool",
                            "tool_call_id": id,
                            "content": result["result"]
                        })
                    yield f"$function_call:${name} {tool_call.function.arguments}$\n\n"
                    tasks.append(process(name, args, tool_call.id))
                await asyncio.gather(*tasks)
                payload["messages"] = messages
                async for recursive_chunk in handleOpenAIStreamRequest(model, payload, tool_metadata):
                    if recursive_chunk:
                        yield recursive_chunk
                break
            if r.delta.content:
                yield f"$data:${r.delta.content}$\n\n"
            elif r.delta.tool_calls:
                for tool_call in r.delta.tool_calls or []:
                    index = tool_call.index
                    if index not in final_tool_calls:
                        final_tool_calls[index] = tool_call
                    final_tool_calls[index].function.arguments += tool_call.function.arguments
    except Exception as e:
        print(f"Error during OpenAI request: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    
async def call_function(name, args):
    response = await http_post(tool_metadata[name.split('-')[0]]['trigger_url'], headers={
        "Content-Type": "application/json"
    },
    json = {
        "function_name": name.split('-')[1],
        "arguments": args,
        "tool_params": tool_metadata[name.split('-')[0]]['parameters']
    })
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": "Failed to generate response", 
                "status_code": response.status_code,
                "response": response.text
        }


async def loadTools(agentData: dict, localToolMetadata: dict, tool_params:dict):
    baseurl = "https://agentman.devprod.sh"
    port = int(os.getenv('PORT', 4000))
    if os.getenv('AGENTMAN_URL') != None:
        baseurl = os.getenv('AGENTMAN_URL')
    for tool in agentData['tools']:
        repo_url, branch_name, tool_name = split_repo_string(tool['source'])
        toolInstanceName = tool['name']
        if repo_url == None and branch_name == None:
            tool_metadata[toolInstanceName] = localToolMetadata[tool_name]
            tool_metadata[toolInstanceName]['trigger_url'] = f"http://localhost:{port}/tools/{tool_name}/trigger"
            tool_metadata[toolInstanceName]['parameters'] = tool_params[toolInstanceName]
            tool_metadata[toolInstanceName]['description'] = (f"""
general tool decription: {tool_metadata[toolInstanceName]['description']}
current instance description: {tool['description']}
            """).strip()
            continue
        else:
            url = hostedUrl(repo_url, branch_name, tool_name)
        try:
            response = await http_get(f"{baseurl}/{url}/functions")
            response.raise_for_status()
        except httpx.HTTPError as e:
            print(repo_url, branch_name, tool_name)
            print(f"Error during GET request: {e}")
            return None
        tool_metadata[toolInstanceName] = response.json()
        tool_metadata[toolInstanceName]['trigger_url'] = f"{baseurl}/{url}/trigger"
        tool_metadata[toolInstanceName]['parameters'] = tool_params[toolInstanceName]
        tool_metadata[toolInstanceName]['description'] = f"""
general tool decription: {tool_metadata[toolInstanceName]['description']}
current instance description: {tool['description']}
        """

def fetch_tool_params():
    
    def yaml_to_dict(data):
        result = {}
        for value in data:
            result[value["name"]] = value["parameters"]
        return result
    
    if os.getenv('TOOL_PARAMS') != None:
        try:
            decoded_data = base64.b64decode(os.getenv('TOOL_PARAMS')).decode('utf-8')
            d = yaml.safe_load(decoded_data)
            return yaml_to_dict(d)
        except base64.binascii.Error as b64_error:
            print(f"Error decoding Base64: {b64_error}")
        except yaml.YAMLError as yaml_error:
            print(f"Error parsing YAML: {yaml_error}")
    
    file_path = '.tool_params.yaml'

    if os.getenv('TOOL_PARAMS_FILE_PATH') != None:
        file_path = os.getenv('TOOL_PARAMS_FILE_PATH')

    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as file:
                d = yaml.safe_load(file)
                return yaml_to_dict(d)
        except yaml.YAMLError as e:
            print(f"Error reading YAML file: {e}")
    else:
        print(f"File '{file_path}' does not exist.")
        return None
    
    
async def setupAgentApp(app, agentData: dict, localToolMetadata: dict):
    if os.getenv('AM_ENV') != 'prod':
        tool_params = fetch_tool_params()
        await loadTools(agentData, localToolMetadata, tool_params)
    
    @app.post('/chat')
    async def conversations(payload: dict):
        tmetadata =tool_metadata
        if os.getenv('AM_ENV') == 'prod':
            tmetadata = payload['tool_metadata']
        if agentData['modelProvider'] == 'openai':
            if payload.get("stream") == True:
                return StreamingResponse(handleOpenAIStreamRequest(model=agentData["model"], payload=payload, tool_metadata=tmetadata), media_type="text/event-stream")
            reqPayload = await handleOpenAIRequest(model=agentData["model"], payload=payload, tool_metadata=tmetadata)
            return reqPayload