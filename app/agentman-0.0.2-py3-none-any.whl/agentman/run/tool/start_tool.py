import yaml
import os
import importlib.util
from fastapi import FastAPI
from ..tool_runner import ToolRunner

httpApp = FastAPI()

# def run():

am_folder_path = '.am'
if not os.path.exists(am_folder_path):
  raise FileNotFoundError(f"The folder '{am_folder_path}' does not exist.")

# Specify the path to your YAML files
tools_yaml_file_path = os.path.join(am_folder_path, 'tools.yaml')
if not os.path.exists(tools_yaml_file_path):
  tools_yaml_file_path = os.path.join(am_folder_path, 'tools.yml')

# Open the YAML files and load their content
with open(tools_yaml_file_path, 'r') as tools_file:
  tools_list = yaml.safe_load(tools_file)

# Transform lists into dictionaries with names as keys
tools = {item['name']: item for item in tools_list}

for tool_info in tools.values():
  module_name, class_name = tool_info['tool'].rsplit('.', 1)

  spec = importlib.util.find_spec(module_name)
  if spec is None:
    raise ImportError(f"Module '{module_name}' not found.")
  module = importlib.util.module_from_spec(spec)
  spec.loader.exec_module(module)
  tool_class = getattr(module, class_name)

  toolRunner = ToolRunner(tool_class, tool_info, httpApp)
  httpApp.mount(f"/tools/{tool_info['name']}", toolRunner.app)
