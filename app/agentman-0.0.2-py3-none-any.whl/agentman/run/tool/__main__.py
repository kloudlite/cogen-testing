import sys
import uvicorn
import os

if __name__ == "__main__":
    if len(sys.argv) < 1:
        print("Usage: python -m agentman.run.tool <toolname>")
    else:
        port = int(os.getenv('PORT', "4000"))
        uvicorn.run("agentman.run.tool.start_tool:httpApp", host="0.0.0.0", port=port, workers=10)