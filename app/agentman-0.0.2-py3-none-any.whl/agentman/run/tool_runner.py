from fastapi import FastAPI

class ToolRunner:
    def __init__(self, Tool, tool_info, app):
      self.app = app
      self.tool_info = tool_info
      self.Tool = Tool
      self.setupRoutes()
    
    def getToolMetadata(self):
      functions_list = []
      for action in self.Tool.__kl_function_metadata__:
        functions_list.append({
          'name': self.Tool.__kl_function_metadata__[action]['name'],
          'description': self.Tool.__kl_function_metadata__[action]['description'],
          'parameters': self.Tool.__kl_function_metadata__[action]['parameters'],
        })
      return {
          'functions': functions_list,
          'name': self.tool_info['name'],
          'description': self.tool_info['description'],
        }

    def setupRoutes(self):
      @self.app.get(f"/tools/{self.tool_info['name']}/functions")
      async def functions():
          functions = self.getToolMetadata()
          return {
              'functions': functions
            }

      @self.app.post(f"/tools/{self.tool_info['name']}/trigger")
      async def trigger(data: dict):
          function_name = data['function_name']
          kwargs = data.get('arguments', {})
          params = data.get("tool_params", [])
          if not function_name:
            return {'error': 'function_name is required'}, 400
          t = self.Tool(**params)
          for m in dir(t):
            if m.startswith('__'):
              continue
            if callable(getattr(t, m)):
              fun = getattr(t, m)
              if fun.__kl__name__ == function_name:
                func = fun
                break
          if not func:
            return {'error': f'Function {function_name} not found'}, 404
          if not callable(func):
            return {'error': f'{function_name} is not callable'}, 400
          try:
            result = func(**kwargs)
          except Exception as e:
            return {'error': str(e)}, 500
          return {'result': result}