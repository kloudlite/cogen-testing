import sys
import subprocess
import hashlib
import os

dockerfileContent = """
FROM python:3.13.1-slim
COPY requirement.txt .
RUN pip install -r requirement.txt
COPY . .
CMD ["python", "-m", "agentman.run.tool"]
"""

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m agentman.ci <giturl> <branch>")
    else:
      giturl = sys.argv[1]
      branch = sys.argv[2] if len(sys.argv) > 2 else "master"
      repo_name = "work"
      if os.path.exists(repo_name):
          subprocess.run(["rm", "-rf", repo_name], check=True)
      subprocess.run(["git", "clone", "--depth", "1", "--branch", branch, giturl, "work"], check=True)

      hash_object = hashlib.sha256(f"{giturl}:{branch}".encode())
      image_tag = hash_object.hexdigest()

      tmp_dir = os.path.join(os.getcwd(), "tmp")
      os.makedirs(tmp_dir, exist_ok=True)
      dockerfile_path = os.path.join(tmp_dir, f"Dockerfile_{repo_name}")
      if not os.path.exists(dockerfile_path):
          with open(dockerfile_path, "w") as dockerfile:
            dockerfile.write(dockerfileContent)
      subprocess.run(["docker", "build", "-f", dockerfile_path, "-t", f"{repo_name}_{image_tag}:latest", "."], cwd=repo_name, check=True)

      if os.path.exists(repo_name):
          subprocess.run(["rm", "-rf", repo_name], check=True)
      if os.path.exists(tmp_dir):
          subprocess.run(["rm", "-rf", tmp_dir], check=True)