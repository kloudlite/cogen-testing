from functools import wraps

def action(description:str, parameters:dict):
  def decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result
    wrapper.__kl__name__ = func.__name__
    wrapper.__kl__doc__ = description
    wrapper.__kl__parameters__ = parameters
    return wrapper
  return decorator

def tool(cls):
  class decoratorCls(cls):
    def __init__(self, *args, **kwargs):
      if "__for__annotations__" in kwargs.keys():
        return None
      super().__init__(*args, **kwargs)
  d = decoratorCls(__for__annotations__=True)
  decoratorCls.__kl_function_metadata__ = {}
  for param in dir(d):
    if param.startswith('__'):
      continue
    if callable(getattr(d, param)):
      fun = getattr(d, param)
      decoratorCls.__kl_function_metadata__[fun.__kl__name__] = {
        'name': fun.__kl__name__,
        'description': fun.__kl__doc__,
        'parameters': fun.__kl__parameters__,
      }
  return decoratorCls
